from flask import Flask, request, render_template, session, redirect, url_for, send_file, flash
from collections import defaultdict
import secrets
import json
import pandas as pd
import os
import urllib.parse

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)

# Define the path to save the voting data
DATA_FOLDER = 'data'
os.makedirs(DATA_FOLDER, exist_ok=True)

# Load valid emails from an Excel or CSV file
EMAIL_LIST_PATH = 'valid_emails.xlsx'  # Update with the correct path to your Excel or CSV file
valid_emails = pd.read_excel('valid_emails.xlsx')['Email'].tolist()

# Dictionary to keep track of votes for each position
votes = {
    'president': defaultdict(int),
    '1st vice president': defaultdict(int),
    '2nd vice president': defaultdict(int),
    'secretary general': defaultdict(int),
    'asst secretary general': defaultdict(int),
    'financial secretary': defaultdict(int),
    'treasurer': defaultdict(int),
    'publicity secretary': defaultdict(int)
}

# Dictionary to store candidates for each position
candidates = {
    'president': ["Yemisi Solanke-Koya", "Aderinsola A Soname"],
    '1st vice president': ["Oyebola Ayeni"],
    '2nd vice president': ["Anuoluwapo Ajayi"],
    'secretary general': ["Bolade Ajani-Sotubo", "Adeola Sorunke"],
    'asst secretary general': ["Morenike Adeniran"],
    'treasurer': ["Titi Okediran"],
    'financial secretary': ["Olubunmi Adesina"],
    'publicity secretary': ["Olubukola Ogunsina"]
}

# Dictionary to store voter information
voter_data = {}


@app.route('/')
def home():
    if 'voter_id' not in session:
        return redirect(url_for('register'))
    return render_template('home.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    error = None
    if request.method == 'POST':
        first_name = request.form['first_name']
        surname = request.form['surname']
        email = request.form['email']
        set_year_start = request.form['set_year_start']
        set_year_end = request.form['set_year_end']
        set_year = f"{set_year_start} to {set_year_end}"
        house = request.form['house']
        phone_number = request.form['phone_number']

        if not first_name or not surname:
            error = "Please enter both first name and surname."
        elif email not in valid_emails:
            error = "Your email is not on the list of valid emails."
        else:
            full_name = f"{first_name} {surname}"
            for voter in voter_data.values():
                if voter['full_name'] == full_name or voter['email'] == email:
                    error = "You have already registered."
                    break
            if not error:
                voter_id = secrets.token_hex(8)
                session['voter_id'] = voter_id
                voter_data[voter_id] = {
                    'first_name': first_name,
                    'surname': surname,
                    'full_name': full_name,
                    'email': email,
                    'set_year': set_year,
                    'house': house,
                    'phone_number': phone_number,
                    'votes': {}
                }
                return redirect(url_for('home'))

    # Ensure the template is always returned
    return render_template('register.html', error=error)



@app.route('/vote/<position>', methods=['GET', 'POST'])
def vote(position):
    try:
        position = urllib.parse.unquote(position)
        app.logger.info(f"Position: {position}")

        if position not in candidates:
            app.logger.error(f"Position '{position}' not found in candidates dictionary.")
            return "Invalid position", 404

        voter_id = session.get('voter_id')
        if not voter_id:
            app.logger.error("Voter ID not found in session.")
            return redirect(url_for('register'))

        if request.method == 'POST':
            if position in voter_data[voter_id]['votes']:
                app.logger.info(f"Voter {voter_id} has already voted for position {position}.")
                return render_template('already_voted.html', position=position)

            candidate = request.form['candidate']
            if candidate not in candidates[position]:
                app.logger.error(f"Candidate '{candidate}' not found for position '{position}'.")
                return "Invalid candidate", 400

            votes[position][candidate] += 1
            voter_data[voter_id]['votes'][position] = candidate
            save_votes_to_file()
            return redirect(url_for('thank_you'))

        if position in voter_data[voter_id]['votes']:
            app.logger.info(f"Voter {voter_id} has already voted for position {position}.")
            return render_template('already_voted.html', position=position)

        return render_template('vote.html', position=position, candidates=candidates[position])
    except Exception as e:
        app.logger.error(f"Error in /vote/{position} route: {e}")
        return "Internal Server Error", 500


@app.route('/thank_you')
def thank_you():
    voter_id = session.get('voter_id')
    if not voter_id:
        return redirect(url_for('register'))

    voter_votes = voter_data[voter_id]['votes']
    all_positions_voted = len(voter_votes) == len(candidates)
    return render_template('thank_you.html', voter=voter_data[voter_id], votes=votes, voter_votes=voter_votes,
                           candidates=candidates, all_positions_voted=all_positions_voted)


@app.route('/logout', methods=['POST'])
def logout():
    session.pop('voter_id', None)
    return redirect(url_for('register'))


@app.route('/download_votes', methods=['POST'])
def download_votes():
    file_path = os.path.join(DATA_FOLDER, 'votes_data.xlsx')
    if not os.path.exists(file_path):
        return "No data available to download", 404
    return send_file(file_path, as_attachment=True)


def save_votes_to_file():
    # Convert voter_data to DataFrame
    df = pd.DataFrame([
        {
            'First Name': voter['first_name'],
            'Surname': voter['surname'],
            'Full Name': voter['full_name'],
            'Email': voter['email'],
            'Set Year': voter['set_year'],
            'House': voter['house'],
            'Phone Number': voter['phone_number'],
            'Position': position,
            'Candidate': candidate
        }
        for voter in voter_data.values()
        for position, candidate in voter['votes'].items()
    ])

    # Save to Excel file
    file_path = os.path.join(DATA_FOLDER, 'votes_data.xlsx')
    df.to_excel(file_path, index=False)


if __name__ == '__main__':
    app.run(debug=True)
